from flask import Flask, request, render_template, jsonify

app = Flask(__name__)

def check_balanced_parentheses(code):
    stack = []
    parentheses = {"(": ")", "[": "]", "{" : "}"}  # Mapping for valid pairs

    for char in code:
        if char in parentheses:  # Opening brackets
            stack.append(char)
        elif char in parentheses.values():  # Closing brackets
            if not stack or parentheses[stack.pop()] != char:
                return False  # Unmatched closing bracket or empty stack

    return not stack  # True if stack is empty, otherwise False

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/check', methods=['POST'])
def check():
    code = request.json.get('code', '')
    result = check_balanced_parentheses(code)
    return jsonify({'balanced': result})

if __name__ == "__main__":
    app.run(debug=True)