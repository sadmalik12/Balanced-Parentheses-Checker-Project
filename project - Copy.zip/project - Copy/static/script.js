document.getElementById("checkButton").addEventListener("click", () => {
    const code = document.getElementById("codeInput").value;

    fetch('/check', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ code })
    })
    .then(response => response.json())
    .then(data => {
        const resultText = data.balanced
            ? "The parentheses are balanced."
            : "The parentheses are NOT balanced.";
        document.getElementById("result").textContent = resultText;
    })
    .catch(error => {
        console.error("Error:", error);
        document.getElementById("result").textContent = "An error occurred.";
    });
});